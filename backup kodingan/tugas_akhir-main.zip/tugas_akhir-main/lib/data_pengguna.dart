class DataPengguna {
  static const String defaultPassword = 'qwertyuiop';
  static const String defaultRole = 'user';
  static const String defaultAdminEmail = 'admin@example.com';

  static const Map<String, dynamic> house = {
    'latitude': -0.11724385920777088,
    'longtitude': 109.38396545133969,
  };
}
